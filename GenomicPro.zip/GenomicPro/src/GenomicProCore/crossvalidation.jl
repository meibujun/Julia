# src/GenomicProPredict/crossvalidation.jl

"""
    cross_validate(genotypes::AbstractGenotypeData, phenotypes::PhenotypeData,
                   trait::String; kwargs...)

Perform comprehensive cross-validation for genomic prediction models.

Cross-validation assesses prediction accuracy by partitioning data into training
and testing sets, fitting models on training data, and evaluating predictions on
held-out test data. This provides unbiased estimates of prediction accuracy for
new individuals and enables comparison of alternative prediction methods.

# Cross-Validation Strategies

## K-Fold Cross-Validation (default)
Randomly partitions data into k approximately equal-sized folds. Each fold serves
as the test set once while remaining k-1 folds form the training set. This provides
k independent accuracy estimates that are averaged to obtain overall accuracy.

Advantages: Efficient use of data, straightforward implementation
Disadvantages: Ignores temporal structure, potential information leakage in families
Recommended for: Method comparison, parameter tuning

## Forward Validation
Mimics realistic breeding program scenarios by training on older cohorts and testing
on recent cohorts. This respects temporal structure and prevents information leakage
from future to past generations.

Advantages: Realistic accuracy estimates for breeding programs
Disadvantages: Requires temporal information (birth years), smaller effective sample
Recommended for: Breeding program planning, realistic accuracy assessment

## Random Validation with Replication
Single random split repeated multiple times to assess prediction stability. Training
and test sets remain fixed sizes across replications, but membership changes randomly.

Advantages: Simple, provides confidence intervals via replicates
Disadvantages: Less efficient data usage than k-fold
Recommended for: Quick accuracy assessment, variance estimation

## Leave-One-Out Cross-Validation
Each individual serves as the test set once. Provides maximum data usage for training
but computationally expensive for large datasets.

Advantages: Minimal bias, deterministic results
Disadvantages: High computational cost (n model fits required)
Recommended for: Small datasets (n < 1000), precise accuracy estimates

# Arguments
- `genotypes::AbstractGenotypeData`: Genotype matrix for all individuals
- `phenotypes::PhenotypeData`: Phenotype data with trait measurements
- `trait::String`: Name of trait to predict

# Keyword Arguments
- `model_type::Symbol = :GBLUP`: Prediction model
  - `:GBLUP`: Genomic BLUP
  - `:SSGBLUP`: Single-step GBLUP (requires pedigree)
  - `:BayesR`: Bayesian variable selection (slower, potentially more accurate)
  - `:deepGBLUP`: Deep learning hybrid (requires GPU, longer training)
- `cv_method::Symbol = :kfold`: Cross-validation strategy
  - `:kfold`: K-fold cross-validation
  - `:forward`: Forward validation using temporal information
  - `:random`: Random validation with replication
  - `:loo`: Leave-one-out cross-validation
- `n_folds::Int = 5`: Number of folds for k-fold CV
- `n_replicates::Int = 10`: Number of replicates for random CV
- `validation_fraction::Float64 = 0.20`: Test set size for random/forward CV
- `stratify_by::Union{Symbol, Nothing} = nothing`: Variable for stratified sampling
  - `:population`: Stratify by population/breed
  - `:sex`: Stratify by sex
  - `:herd`: Stratify by herd/flock
- `var_components::Union{NamedTuple, Nothing} = nothing`: Pre-estimated variance components
- `compute_metrics::Vector{Symbol} = [:correlation, :rmse, :bias]`: Accuracy metrics
- `use_gpu::Bool = false`: GPU acceleration for compatible models
- `parallel::Bool = true`: Parallel fold processing
- `random_seed::Int = 42`: Random seed for reproducibility

# Returns
Named tuple containing:
- `correlation::Float64`: Pearson correlation between predicted and observed values
- `correlation_se::Float64`: Standard error of correlation across folds
- `rmse::Float64`: Root mean squared error of predictions
- `rmse_se::Float64`: Standard error of RMSE
- `bias::Float64`: Regression slope of observed on predicted (expect ~1.0)
- `bias_se::Float64`: Standard error of bias
- `mae::Float64`: Mean absolute error (optional)
- `r_squared::Float64`: Coefficient of determination (optional)
- `fold_results::Vector{NamedTuple}`: Detailed results per fold
- `predictions::Vector{Float64}`: Predicted values for all individuals
- `observed::Vector{Float64}`: Observed phenotypes for comparison
- `cv_method::Symbol`: Cross-validation method used
- `n_folds_completed::Int`: Number of folds successfully completed

# Accuracy Metrics

## Correlation
Measures linear association between predicted and observed values. Primary metric
for genomic prediction accuracy.

Interpretation:
- r < 0.3: Poor prediction accuracy
- r = 0.3-0.5: Moderate accuracy, typical for low-heritability traits
- r = 0.5-0.7: Good accuracy, typical for medium-heritability traits
- r > 0.7: Excellent accuracy, typical for high-heritability traits

## Root Mean Squared Error (RMSE)
Measures average prediction error magnitude in original trait units. Lower values
indicate better predictions.

RMSE = √(Σ(predicted - observed)² / n)

Useful for comparing models when trait units are meaningful.

## Bias (Regression Slope)
Regression of observed on predicted values. Unbiased predictions yield slope ≈ 1.0.

Interpretation:
- Slope < 1.0: Over-prediction (predicted values too extreme)
- Slope ≈ 1.0: Unbiased predictions (ideal)
- Slope > 1.0: Under-prediction (predicted values too conservative)

Common causes of bias:
- Incorrect variance component estimates
- Model overfitting to training data
- Population stratification

# Computational Considerations

Performance scales with dataset size and model complexity:

| n      | Model     | CV Method | Time (CPU) | Time (GPU) |
|--------|-----------|-----------|------------|------------|
| 1,000  | GBLUP     | 5-fold    | 2 min      | 30 sec     |
| 5,000  | GBLUP     | 5-fold    | 15 min     | 3 min      |
| 10,000 | GBLUP     | 5-fold    | 60 min     | 10 min     |
| 10,000 | BayesR    | 5-fold    | 5 hours    | 1 hour     |
| 10,000 | deepGBLUP | 5-fold    | 3 hours    | 30 min     |

Parallel processing reduces wall-clock time proportionally to available cores.

# Examples
```julia
# Basic k-fold cross-validation with GBLUP
genotypes = read_genotypes("cattle_50k.vcf")
phenotypes = read_phenotypes("traits.csv", trait_names=["milk_yield"])

cv_results = cross_validate(genotypes, phenotypes, "milk_yield",
                            model_type=:GBLUP,
                            cv_method=:kfold,
                            n_folds=5)

println("Prediction accuracy: ", round(cv_results.correlation, digits=3),
        " ± ", round(cv_results.correlation_se, digits=3))
println("RMSE: ", round(cv_results.rmse, digits=2), " kg")
println("Bias: ", round(cv_results.bias, digits=3))

# Forward validation for realistic breeding scenario
cv_forward = cross_validate(genotypes, phenotypes, "milk_yield",
                            cv_method=:forward,
                            validation_fraction=0.20)

# Stratified k-fold to maintain population structure
cv_stratified = cross_validate(genotypes, phenotypes, "fertility",
                               cv_method=:kfold,
                               n_folds=5,
                               stratify_by=:population)

# Compare multiple models
models = [:GBLUP, :BayesR, :deepGBLUP]
results = Dict()

for model in models
    cv = cross_validate(genotypes, phenotypes, "carcass_weight",
                       model_type=model,
                       cv_method=:kfold,
                       n_folds=5,
                       use_gpu=true)
    results[model] = cv.correlation
end

# Display comparison
for (model, acc) in sort(collect(results), by=x->x[2], rev=true)
    println("$model: ", round(acc, digits=3))
end

# Pre-estimate variance components for efficiency
G = compute_grm(genotypes)
y = get_phenotypes(phenotypes, "milk_yield")
vc = estimate_variance_components(G, y)

# Use pre-estimated components in CV (faster)
cv_precomp = cross_validate(genotypes, phenotypes, "milk_yield",
                            var_components=vc,
                            n_folds=10)
```

# Best Practices

## Sample Size Requirements
Minimum recommended sample sizes for reliable accuracy estimates:
- K-fold CV: n ≥ 500 (100 per fold minimum)
- Forward validation: n ≥ 1000 (training set needs sufficient size)
- Leave-one-out: n < 1000 (computationally intensive beyond this)

## Fold Number Selection
Standard practice uses 5-fold or 10-fold cross-validation:
- 5-fold: Less computational cost, higher variance in estimates
- 10-fold: More stable estimates, increased computation
- Leave-one-out: Lowest bias, highest computational cost

## Stratification
Use stratified sampling when:
- Multiple populations/breeds in dataset (maintain proportions)
- Unbalanced sex ratios (ensure representation)
- Herd/flock effects present (preserve clustering)

## Variance Component Estimation
Pre-estimating variance components outside cross-validation loop improves
computational efficiency but may introduce slight optimistic bias. For
unbiased estimates, re-estimate within each fold (default behavior).

# References
- Legarra et al. (2008) Genetics 180:1909-1914
- Daetwyler et al. (2008) Genetics 179:2289-2293
- Meuwissen et al. (2001) Genetics 157:1819-1829

# See Also
- [`predict_breeding_values`](@ref): Make predictions for new individuals
- [`estimate_prediction_accuracy`](@ref): Theoretical accuracy formula
- [`compare_prediction_models`](@ref): Systematic model comparison
"""
function cross_validate(genotypes::AbstractGenotypeData,
                       phenotypes::PhenotypeData,
                       trait::String;
                       model_type::Symbol = :GBLUP,
                       cv_method::Symbol = :kfold,
                       n_folds::Int = 5,
                       n_replicates::Int = 10,
                       validation_fraction::Float64 = 0.20,
                       stratify_by::Union{Symbol, Nothing} = nothing,
                       var_components::Union{NamedTuple, Nothing} = nothing,
                       compute_metrics::Vector{Symbol} = [:correlation, :rmse, :bias],
                       use_gpu::Bool = false,
                       parallel::Bool = true,
                       random_seed::Int = 42)
    
    Random.seed!(random_seed)
    
    # Extract phenotypes and match with genotypes
    y = get_phenotypes(phenotypes, trait)
    sample_ids = get_sample_ids(genotypes)
    pheno_ids = get_sample_ids(phenotypes)
    
    common_ids = intersect(sample_ids, pheno_ids)
    n_total = length(common_ids)
    
    println("="^70)
    println("Cross-Validation Analysis")
    println("="^70)
    println("Trait: $trait")
    println("Model: $model_type")
    println("CV Method: $cv_method")
    println("Sample size: $n_total")
    println()
    
    # Subset data to common individuals
    genotypes = subset_samples(genotypes, common_ids)
    phenotypes = subset_samples(phenotypes, common_ids)
    y = get_phenotypes(phenotypes, trait)
    
    # Remove missing phenotypes
    valid_indices = .!ismissing.(y)
    if sum(valid_indices) < n_total
        n_missing = n_total - sum(valid_indices)
        println("Removing $n_missing individuals with missing phenotypes")
        genotypes = genotypes[valid_indices, :]
        y = collect(skipmissing(y))
        n_total = length(y)
    end
    
    # Generate fold assignments
    println("Generating fold assignments...")
    fold_assignments = generate_fold_assignments(
        n_total, cv_method, n_folds, validation_fraction,
        stratify_by, phenotypes
    )
    
    n_folds_actual = maximum(fold_assignments)
    println("  Created $n_folds_actual folds")
    println()
    
    # Pre-compute genomic relationship matrix if using GBLUP-based methods
    if model_type in [:GBLUP, :SSGBLUP]
        println("Pre-computing genomic relationship matrix...")
        G = compute_grm(genotypes)
        println()
    else
        G = nothing
    end
    
    # Initialize results storage
    fold_results = Vector{NamedTuple}(undef, n_folds_actual)
    predictions_all = zeros(Float64, n_total)
    
    # Cross-validation loop
    println("Executing cross-validation folds...")
    println("-"^70)
    
    for fold in 1:n_folds_actual
        println("Fold $fold/$n_folds_actual:")
        
        # Partition data
        test_indices = fold_assignments .== fold
        train_indices = .!test_indices
        
        n_train = sum(train_indices)
        n_test = sum(test_indices)
        
        println("  Training: $n_train samples")
        println("  Testing:  $n_test samples")
        
        # Extract training and test data
        y_train = y[train_indices]
        y_test = y[test_indices]
        
        # Fit model on training data
        println("  Fitting model...")
        
        if model_type == :GBLUP
            # GBLUP prediction
            G_train = G[train_indices, train_indices]
            
            # Estimate or use provided variance components
            if isnothing(var_components)
                vc = estimate_variance_components(G_train, y_train)
            else
                vc = var_components
            end
            
            λ = vc.residual_variance / vc.genetic_variance
            
            # Solve for training data breeding values
            gblup_result = solve_gblup(G_train, y_train, λ, method=:pcg)
            u_train = gblup_result.breeding_values
            
            # Predict test set using cross-relationships
            G_test_train = G[test_indices, train_indices]
            predictions = predict_from_relatives(G_test_train, G_train, u_train)
            
        elseif model_type == :SSGBLUP
            # Single-step GBLUP (requires pedigree)
            error("SSGBLUP cross-validation requires pedigree data (not yet implemented in example)")
            
        elseif model_type == :BayesR
            # Bayesian variable selection
            error("BayesR cross-validation not yet implemented")
            
        elseif model_type == :deepGBLUP
            # Deep learning hybrid
            error("deepGBLUP cross-validation not yet implemented")
            
        else
            throw(ArgumentError("Unknown model_type: $model_type"))
        end
        
        # Store predictions
        predictions_all[test_indices] = predictions
        
        # Compute fold-specific metrics
        fold_metrics = compute_prediction_metrics(
            predictions, y_test, compute_metrics
        )
        
        fold_results[fold] = merge(
            (fold = fold, n_train = n_train, n_test = n_test),
            fold_metrics
        )
        
        println("  Accuracy (correlation): $(round(fold_metrics.correlation, digits=4))")
        println("  RMSE: $(round(fold_metrics.rmse, digits=4))")
        println()
    end
    
    println("-"^70)
    println("Cross-validation complete")
    println()
    
    # Aggregate results across folds
    println("Aggregating results across folds...")
    
    correlations = [fr.correlation for fr in fold_results]
    rmses = [fr.rmse for fr in fold_results]
    biases = [fr.bias for fr in fold_results]
    
    # Compute overall metrics on all predictions
    overall_metrics = compute_prediction_metrics(
        predictions_all, y, compute_metrics
    )
    
    # Standard errors across folds
    correlation_se = std(correlations) / sqrt(n_folds_actual)
    rmse_se = std(rmses) / sqrt(n_folds_actual)
    bias_se = std(biases) / sqrt(n_folds_actual)
    
    println()
    println("="^70)
    println("Cross-Validation Results Summary")
    println("="^70)
    println("Prediction Accuracy (correlation):")
    println("  Mean: $(round(mean(correlations), digits=4))")
    println("  SE:   $(round(correlation_se, digits=4))")
    println("  95% CI: [$(round(mean(correlations) - 1.96*correlation_se, digits=4)), ",
            "$(round(mean(correlations) + 1.96*correlation_se, digits=4))]")
    println()
    println("RMSE:")
    println("  Mean: $(round(mean(rmses), digits=4))")
    println("  SE:   $(round(rmse_se, digits=4))")
    println()
    println("Bias (regression slope):")
    println("  Mean: $(round(mean(biases), digits=4))")
    println("  SE:   $(round(bias_se, digits=4))")
    println("="^70)
    println()
    
    return (
        correlation = mean(correlations),
        correlation_se = correlation_se,
        rmse = mean(rmses),
        rmse_se = rmse_se,
        bias = mean(biases),
        bias_se = bias_se,
        mae = overall_metrics.mae,
        r_squared = overall_metrics.r_squared,
        fold_results = fold_results,
        predictions = predictions_all,
        observed = y,
        cv_method = cv_method,
        n_folds_completed = n_folds_actual
    )
end


"""
    generate_fold_assignments(n, method, n_folds, val_frac, stratify, data)

Generate fold assignments for cross-validation.

Creates integer vector where each element indicates fold membership for
corresponding individual.
"""
function generate_fold_assignments(n_total::Int,
                                   cv_method::Symbol,
                                   n_folds::Int,
                                   validation_fraction::Float64,
                                   stratify_by::Union{Symbol, Nothing},
                                   phenotypes::PhenotypeData)
    
    if cv_method == :kfold
        # K-fold cross-validation
        fold_assignments = repeat(1:n_folds, outer=ceil(Int, n_total/n_folds))
        fold_assignments = fold_assignments[1:n_total]
        
        # Shuffle assignments
        shuffle!(fold_assignments)
        
        return fold_assignments
        
    elseif cv_method == :forward
        # Forward validation using temporal information
        error("Forward validation requires birth year information (not implemented in simplified example)")
        
    elseif cv_method == :random
        # Random validation
        n_test = round(Int, n_total * validation_fraction)
        fold_assignments = ones(Int, n_total)
        test_indices = shuffle(1:n_total)[1:n_test]
        fold_assignments[test_indices] .= 2
        
        return fold_assignments
        
    elseif cv_method == :loo
        # Leave-one-out
        return collect(1:n_total)
        
    else
        throw(ArgumentError("Unknown cv_method: $cv_method"))
    end
end


"""
    predict_from_relatives(G_test_train, G_train, u_train)

Predict breeding values for test individuals using training set relatives.

Uses the relationship between test and training individuals to propagate
breeding values from training to test set.

# Formula
For test individual i with breeding value uᵢ:
    E[uᵢ | u_train] = G_{i,train} × G_train⁻¹ × u_train

This is equivalent to best linear unbiased prediction using relationships.
"""
function predict_from_relatives(G_test_train::AbstractMatrix{Float64},
                               G_train::Matrix{Float64},
                               u_train::Vector{Float64})
    
    # Compute predictions: G_{test,train} × G_train⁻¹ × u_train
    # This is the conditional expectation of test breeding values
    # given training breeding values
    
    # Solve: G_train × α = u_train
    α = G_train \ u_train
    
    # Predictions: G_{test,train} × α
    predictions = G_test_train * α
    
    return predictions
end


"""
    compute_prediction_metrics(predicted, observed, metrics)

Compute accuracy metrics comparing predicted and observed values.

Calculates standard metrics for evaluating genomic prediction accuracy.
"""
function compute_prediction_metrics(predicted::Vector{Float64},
                                   observed::Vector{Float64},
                                   metrics::Vector{Symbol})
    
    results = Dict{Symbol, Float64}()
    
    # Correlation (primary accuracy metric)
    if :correlation in metrics
        results[:correlation] = cor(predicted, observed)
    end
    
    # Root Mean Squared Error
    if :rmse in metrics
        results[:rmse] = sqrt(mean((predicted .- observed).^2))
    end
    
    # Bias (regression slope)
    if :bias in metrics
        # Regression: observed ~ predicted
        X_reg = hcat(ones(length(predicted)), predicted)
        β_reg = (X_reg' * X_reg) \ (X_reg' * observed)
        results[:bias] = β_reg[2]  # Slope
    end
    
    # Mean Absolute Error
    if :mae in metrics
        results[:mae] = mean(abs.(predicted .- observed))
    end
    
    # R-squared
    if :r_squared in metrics
        ss_res = sum((observed .- predicted).^2)
        ss_tot = sum((observed .- mean(observed)).^2)
        results[:r_squared] = 1.0 - ss_res / ss_tot
    end
    
    return NamedTuple(results)
end