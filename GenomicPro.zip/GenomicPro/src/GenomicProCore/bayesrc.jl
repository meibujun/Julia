# src/GenomicProPredict/bayesrc.jl

"""
    BayesRCModel <: AbstractBayesianModel

BayesRC model incorporating functional genomic annotations.

BayesRC extends BayesR by allowing mixing proportions to depend on functional
annotations through a logistic regression framework. This integration improves
power for detecting causal variants by leveraging prior biological knowledge about
regulatory regions, conservation patterns, and gene expression relationships.

# Mathematical Model

The annotation-informed mixing proportions follow:

    logit(πⱼₖ) = μₖ + Σₗ αₗₖ × annotationⱼₗ

where:
- πⱼₖ is the probability marker j belongs to component k
- μₖ is the baseline log-odds for component k
- αₗₖ quantifies how annotation l influences component k assignment
- annotationⱼₗ is the l-th annotation value for marker j

This formulation enables markers in regulatory regions or with strong conservation
to have higher prior probability of non-zero effects.

# Annotation Types

Common genomic annotations include:

**Regulatory Annotations**
- Promoter regions (±2kb from transcription start sites)
- Enhancers identified by histone modifications (H3K27ac, H3K4me1)
- Open chromatin regions from ATAC-seq or DNase-seq
- Transcription factor binding sites

**Conservation Scores**
- PhyloP conservation across species
- PhastCons conserved elements
- GERP rejected substitutions

**Functional Evidence**
- eQTL association strength
- Chromatin interaction frequency (Hi-C, ChIA-PET)
- Allele-specific expression
- Protein-coding consequences

# Fields
- `base_model::BayesRModel`: Underlying BayesR model structure
- `n_annotations::Int`: Number of functional annotations
- `annotation_names::Vector{String}`: Descriptive names for annotations
- `prior_annotation_effects::Vector{Float64}`: Prior means for α parameters

# Examples
```julia
# Load functional annotations
annotations = load_annotations("regulatory_marks.bed", genotypes)

# Create BayesRC model
model = BayesRCModel(
    n_annotations = size(annotations, 2),
    annotation_names = ["promoter", "enhancer", "conservation"],
    prior_annotation_effects = zeros(3)  # Neutral prior
)

# Run MCMC with annotations
results = run_bayesrc_mcmc(model, genotypes, phenotypes, annotations,
                          n_iterations = 50000,
                          burn_in = 10000)

# Examine annotation effects
for (name, effect) in zip(model.annotation_names, results.annotation_effects)
    println("$name effect: $(round(effect, digits=3))")
    println("  95% CI: [$(round(results.annotation_ci[name][1], digits=3)), ",
            "$(round(results.annotation_ci[name][2], digits=3))]")
end

# Identify enriched annotations
significant_annots = [name for (name, ci) in results.annotation_ci 
                     if ci[1] > 0.0 || ci[2] < 0.0]
println("Significant annotations: ", join(significant_annots, ", "))
```

# Biological Interpretation

Positive annotation effects (α > 0) indicate markers with that annotation have
increased probability of belonging to non-null components, suggesting functional
enrichment. Negative effects (α < 0) imply depletion of causal variants in
annotated regions, potentially indicating neutral or structural variation.

Effect magnitude interpretation:
- |α| > 1.0: Strong enrichment or depletion
- |α| = 0.5-1.0: Moderate effect
- |α| < 0.5: Weak effect

# References
- MacLeod et al. (2016) Genetics 203:973-983 (Original BayesRC)
- Xiang et al. (2021) Nat Commun 12:489 (Annotation integration)

# See Also
- [`run_bayesrc_mcmc`](@ref): MCMC sampling with annotations
- [`load_annotations`](@ref): Import annotation data
- [`test_annotation_enrichment`](@ref): Statistical enrichment testing
"""
struct BayesRCModel <: AbstractBayesianModel
    base_model::BayesRModel
    n_annotations::Int
    annotation_names::Vector{String}
    prior_annotation_effects::Vector{Float64}
    
    function BayesRCModel(;
                         n_annotations::Int,
                         annotation_names::Vector{String},
                         prior_annotation_effects::Vector{Float64} = zeros(n_annotations),
                         base_model::BayesRModel = BayesRModel())
        
        @assert n_annotations == length(annotation_names) "Mismatch in annotation count"
        @assert n_annotations == length(prior_annotation_effects) "Mismatch in prior effects length"
        
        new(base_model, n_annotations, annotation_names, prior_annotation_effects)
    end
end