# src/GenomicProPredict/ssgblup.jl

"""
    solve_ssgblup(G::Matrix{Float64}, A::Matrix{Float64}, 
                  genotyped_indices::Vector{Int}, y::Vector{Float64}, 
                  λ::Float64; kwargs...)

Solve Single-Step Genomic BLUP combining pedigree and genomic information.

Single-Step GBLUP (SSGBLUP) enables simultaneous evaluation of genotyped and
non-genotyped animals in a unified framework. The method blends pedigree-based
relationships (A matrix) with genomic relationships (G matrix) through the
H-matrix formulation.

# Mathematical Foundation

## H-Matrix Construction
The unified relationship matrix H combines pedigree (A) and genomic (G) information:

    H = [A₁₁ + A₁₂A₂₂⁻¹(G - A₂₂)A₂₂⁻¹A₂₁   A₁₂A₂₂⁻¹G    ]
        [GA₂₂⁻¹A₂₁                         G            ]

where:
- Subscript 1: non-genotyped animals
- Subscript 2: genotyped animals
- A: pedigree-based numerator relationship matrix
- G: genomic relationship matrix
- A₂₂: pedigree relationships among genotyped animals only

## Practical Implementation
Direct construction of H is computationally prohibitive for large datasets.
Instead, we construct H⁻¹ using sparse matrix decomposition:

    H⁻¹ = A⁻¹ + [0      0    ]
                 [0   G⁻¹-A₂₂⁻¹]

This formulation avoids explicit inversion of large matrices and exploits
sparsity in A⁻¹ for computational efficiency.

## Mixed Model Equations
The single-step system solves:

    [X'X    X'Z  ][β] = [X'y]
    [Z'X  Z'Z+H⁻¹λ][u]   [Z'y]

where u contains breeding values for both genotyped and non-genotyped animals.

# Arguments
- `G::Matrix{Float64}`: Genomic relationship matrix for genotyped animals (n_g × n_g)
- `A::Matrix{Float64}`: Pedigree numerator relationship matrix for all animals (n × n)
- `genotyped_indices::Vector{Int}`: Indices of genotyped animals in full pedigree
- `y::Vector{Float64}`: Phenotype vector for all animals (n × 1)
- `λ::Float64`: Variance ratio σ²ₑ/σ²ᵤ

# Keyword Arguments
- `method::Symbol = :pcg`: Solution method (:direct or :pcg)
- `X::Union{Matrix{Float64}, Nothing} = nothing`: Fixed effect design matrix
- `validate_compatibility::Bool = true`: Check G and A₂₂ compatibility
- `blend_parameter::Float64 = 1.0`: Blending parameter for G-A₂₂ difference
- `tolerance::Float64 = 1e-6`: PCG convergence tolerance
- `max_iterations::Int = 1000`: Maximum PCG iterations

# Returns
Named tuple containing:
- `breeding_values::Vector{Float64}`: Breeding values for all animals (genotyped + non-genotyped)
- `genotyped_gebvs::Vector{Float64}`: Subset of breeding values for genotyped animals
- `nongenotyped_ebvs::Vector{Float64}`: Breeding values for non-genotyped animals
- `compatibility_metrics::NamedTuple`: Diagnostics comparing G and A₂₂
- `iterations::Int`: PCG iterations (0 for direct method)
- `converged::Bool`: Convergence status

# Compatibility Validation

The method checks compatibility between G and A₂₂:
- Correlation: Should be >0.8 for well-matched data
- Regression slope: Should be near 1.0
- Mean difference: Should be near 0.0

Large discrepancies suggest:
- Genotyping platform bias (array vs sequence)
- Different allele frequency bases
- Population stratification
- Quality control differences

# Computational Complexity
- Time: O(n² + n_g³) where n = total animals, n_g = genotyped
  - Dominated by G⁻¹ and A₂₂⁻¹ computations
- Space: O(n²) for dense A, O(n) for sparse A
- PCG reduces to O(n²k) with k iterations

# Examples
```julia
# Read pedigree and compute A matrix
pedigree = read_pedigree("family.ped")
A = compute_numerator_relationship(pedigree)

# Compute genomic relationship matrix
G = compute_grm(genotypes)

# Identify which animals in pedigree are genotyped
genotyped_ids = get_sample_ids(genotypes)
all_ids = get_individual_ids(pedigree)
genotyped_indices = findall(in(genotyped_ids), all_ids)

# Estimate variance components
vc = estimate_variance_components(G, phenotypes[genotyped_indices])
λ = vc.residual_variance / vc.genetic_variance

# Solve SSGBLUP
result = solve_ssgblup(G, A, genotyped_indices, phenotypes, λ)

# Extract results
all_ebvs = result.breeding_values
genotyped_gebvs = result.genotyped_gebvs
nongenotyped_ebvs = result.nongenotyped_ebvs

# Check compatibility
println("G-A correlation: ", result.compatibility_metrics.correlation)
```

# Advantages over GBLUP
1. Utilizes all available phenotypes (genotyped + non-genotyped)
2. Maintains single evaluation system across generations
3. Provides breeding values for young animals not yet genotyped
4. Accounts for pedigree information in genomic predictions
5. Enables progeny testing integration with genomic selection

# References
- Legarra et al. (2009) J Dairy Sci 92:4656-4663
- Aguilar et al. (2010) J Dairy Sci 93:743-752
- Christensen & Lund (2010) Genet Sel Evol 42:2

# See Also
- [`compute_numerator_relationship`](@ref): Pedigree relationship matrix
- [`validate_pedigree`](@ref): Pedigree quality control
- [`blend_G_and_A`](@ref): Compatibility adjustment methods
"""
function solve_ssgblup(G::Matrix{Float64},
                      A::Matrix{Float64},
                      genotyped_indices::Vector{Int},
                      y::Vector{Float64},
                      λ::Float64;
                      method::Symbol = :pcg,
                      X::Union{Matrix{Float64}, Nothing} = nothing,
                      validate_compatibility::Bool = true,
                      blend_parameter::Float64 = 1.0,
                      tolerance::Float64 = 1e-6,
                      max_iterations::Int = 1000)
    
    n_total = length(y)
    n_genotyped = length(genotyped_indices)
    
    # Validate inputs
    @assert size(A) == (n_total, n_total) "A must be n×n where n is total animals"
    @assert size(G) == (n_genotyped, n_genotyped) "G must be n_g×n_g for genotyped animals"
    @assert all(1 .<= genotyped_indices .<= n_total) "Invalid genotyped indices"
    
    println("Solving Single-Step GBLUP...")
    println("  Total animals: $n_total")
    println("  Genotyped animals: $n_genotyped")
    println("  Non-genotyped animals: $(n_total - n_genotyped)")
    println()
    
    # Extract A₂₂ (relationships among genotyped animals from pedigree)
    println("  Extracting A₂₂ submatrix...")
    A22 = A[genotyped_indices, genotyped_indices]
    
    # Validate G and A₂₂ compatibility
    if validate_compatibility
        println("  Validating G and A₂₂ compatibility...")
        compat_metrics = assess_G_A22_compatibility(G, A22)
        
        println("    Correlation: $(round(compat_metrics.correlation, digits=3))")
        println("    Regression slope: $(round(compat_metrics.regression_slope, digits=3))")
        println("    Mean difference: $(round(compat_metrics.mean_difference, digits=4))")
        
        if compat_metrics.correlation < 0.70
            @warn "Low G-A₂₂ correlation ($(round(compat_metrics.correlation, digits=2))), consider checking data quality"
        end
    else
        compat_metrics = (correlation = NaN, regression_slope = NaN, mean_difference = NaN)
    end
    println()
    
    # Construct H⁻¹ using sparse formulation
    println("  Constructing H⁻¹ matrix...")
    H_inv = construct_H_inverse(A, G, A22, genotyped_indices, blend_parameter)
    
    # Absorb fixed effects if provided
    if isnothing(X)
        X = ones(Float64, n_total, 1)
    end
    y_corrected, β = absorb_fixed_effects(X, y)
    
    # Solve mixed model equations
    if method == :direct
        println("  Solving via direct method...")
        C = I + H_inv * λ
        u = cholesky(Symmetric(C)) \ y_corrected
        iterations = 0
        converged = true
        residual_norm = norm(y_corrected - C * u)
    else  # :pcg
        println("  Solving via PCG...")
        
        # PCG solver adapted for H⁻¹
        result = pcg_with_H_inverse(H_inv, y_corrected, λ, tolerance, max_iterations)
        u = result.solution
        iterations = result.iterations
        converged = result.converged
        residual_norm = result.residual_norm
    end
    
    # Extract breeding values for genotyped and non-genotyped animals
    genotyped_gebvs = u[genotyped_indices]
    
    nongenotyped_mask = trues(n_total)
    nongenotyped_mask[genotyped_indices] .= false
    nongenotyped_ebvs = u[nongenotyped_mask]
    
    println()
    println("  ✓ SSGBLUP solution complete")
    println("  Iterations: $iterations")
    println("  Residual norm: $(round(residual_norm, sigdigits=6))")
    println()
    
    return (
        breeding_values = u,
        genotyped_gebvs = genotyped_gebvs,
        nongenotyped_ebvs = nongenotyped_ebvs,
        fixed_effects = β,
        compatibility_metrics = compat_metrics,
        iterations = iterations,
        residual_norm = residual_norm,
        converged = converged
    )
end


"""
    assess_G_A22_compatibility(G, A22)

Assess compatibility between genomic and pedigree relationship matrices.

Compares G (from markers) with A₂₂ (from pedigree) to identify potential
data quality issues or incompatibilities.
"""
function assess_G_A22_compatibility(G::Matrix{Float64}, A22::Matrix{Float64})
    n = size(G, 1)
    
    # Extract off-diagonal elements (relationships)
    G_offdiag = [G[i,j] for i in 1:n, j in 1:n if i != j]
    A22_offdiag = [A22[i,j] for i in 1:n, j in 1:n if i != j]
    
    # Compute correlation
    correlation = cor(G_offdiag, A22_offdiag)
    
    # Regression of G on A₂₂
    X_reg = hcat(ones(length(A22_offdiag)), A22_offdiag)
    β_reg = (X_reg' * X_reg) \ (X_reg' * G_offdiag)
    regression_slope = β_reg[2]
    
    # Mean difference
    mean_difference = mean(G_offdiag) - mean(A22_offdiag)
    
    return (
        correlation = correlation,
        regression_slope = regression_slope,
        mean_difference = mean_difference
    )
end


"""
    construct_H_inverse(A, G, A22, genotyped_indices, blend_param)

Construct inverse of H matrix using sparse formulation.

Uses H⁻¹ = A⁻¹ + [0, 0; 0, G⁻¹ - A₂₂⁻¹] to avoid forming H explicitly.
"""
function construct_H_inverse(A::Matrix{Float64},
                            G::Matrix{Float64},
                            A22::Matrix{Float64},
                            genotyped_indices::Vector{Int},
                            blend_parameter::Float64)
    
    n_total = size(A, 1)
    n_genotyped = length(genotyped_indices)
    
    # Compute A⁻¹ (typically sparse for pedigrees)
    println("    Computing A⁻¹...")
    A_inv = inv(A)
    
    # Compute G⁻¹
    println("    Computing G⁻¹...")
    G_inv = inv(G)
    
    # Compute A₂₂⁻¹
    println("    Computing A₂₂⁻¹...")
    A22_inv = inv(A22)
    
    # Construct H⁻¹ = A⁻¹ + augmentation term
    H_inv = copy(A_inv)
    
    # Add (G⁻¹ - A₂₂⁻¹) to positions corresponding to genotyped animals
    # Apply blending parameter: blend_param × (G⁻¹ - A₂₂⁻¹)
    augmentation = blend_parameter .* (G_inv - A22_inv)
    
    for (i_idx, i) in enumerate(genotyped_indices)
        for (j_idx, j) in enumerate(genotyped_indices)
            H_inv[i, j] += augmentation[i_idx, j_idx]
        end
    end
    
    return H_inv
end


"""
    pcg_with_H_inverse(H_inv, y, λ, tol, max_iter)

Preconditioned conjugate gradient solver for system with H⁻¹.

Solves (I + H⁻¹λ)u = y without explicitly forming coefficient matrix.
"""
function pcg_with_H_inverse(H_inv::Matrix{Float64},
                           y::Vector{Float64},
                           λ::Float64,
                           tolerance::Float64,
                           max_iterations::Int)
    
    n = length(y)
    
    # Initialize
    u = zeros(Float64, n)
    r = copy(y)
    
    # Diagonal preconditioner: M = diag(I + H⁻¹λ)
    M_diag_inv = 1.0 ./ (1.0 .+ diag(H_inv) .* λ)
    
    z = r .* M_diag_inv
    p = copy(z)
    rz_old = dot(r, z)
    
    converged = false
    
    for k in 1:max_iterations
        # Compute (I + H⁻¹λ)p
        Cp = p + (H_inv * p) * λ
        
        α = rz_old / dot(p, Cp)
        u .+= α .* p
        r .-= α .* Cp
        
        residual_norm = norm(r)
        
        if k % 25 == 0
            println("    PCG iteration $k: residual = $(round(residual_norm, sigdigits=6))")
        end
        
        if residual_norm < tolerance
            converged = true
            println("    Converged in $k iterations")
            break
        end
        
        z = r .* M_diag_inv
        rz_new = dot(r, z)
        β = rz_new / rz_old
        p .= z .+ β .* p
        rz_old = rz_new
    end
    
    return (
        solution = u,
        iterations = min(max_iterations, max_iterations),
        residual_norm = norm(r),
        converged = converged
    )
end